﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PratikLift
{
    internal class Idle : ILift
    {
        public void LiftCloseDoor(lift lift)
        {
        }

        public void LiftMoveDown(lift lift)
        {
        }

        public void LiftMoveUp(lift lift)
        {
        }

        public void LiftOpenDoor(lift lift)
        {
        }
    }
}
