﻿namespace PratikLift
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mainBase = new System.Windows.Forms.PictureBox();
            this.mathiBolau = new System.Windows.Forms.Button();
            this.show = new System.Windows.Forms.Button();
            this.mathiTimer = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.ldoor1 = new System.Windows.Forms.PictureBox();
            this.rdoor1 = new System.Windows.Forms.PictureBox();
            this.rdoorg = new System.Windows.Forms.PictureBox();
            this.ldoorg = new System.Windows.Forms.PictureBox();
            this.TalaBolau = new System.Windows.Forms.Button();
            this.mathi = new System.Windows.Forms.Button();
            this.tala = new System.Windows.Forms.Button();
            this.dhokaOpen = new System.Windows.Forms.Button();
            this.dhokaClose = new System.Windows.Forms.Button();
            this.talaTimer = new System.Windows.Forms.Timer(this.components);
            this.dhokaKhulla = new System.Windows.Forms.Timer(this.components);
            this.dhokaBanda = new System.Windows.Forms.Timer(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.mainBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ldoor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoor1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoorg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ldoorg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // mainBase
            // 
            this.mainBase.BackColor = System.Drawing.Color.RosyBrown;
            this.mainBase.Location = new System.Drawing.Point(115, 349);
            this.mainBase.Name = "mainBase";
            this.mainBase.Size = new System.Drawing.Size(178, 211);
            this.mainBase.TabIndex = 0;
            this.mainBase.TabStop = false;
            // 
            // mathiBolau
            // 
            this.mathiBolau.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mathiBolau.Location = new System.Drawing.Point(321, 119);
            this.mathiBolau.Name = "mathiBolau";
            this.mathiBolau.Size = new System.Drawing.Size(55, 58);
            this.mathiBolau.TabIndex = 1;
            this.mathiBolau.UseVisualStyleBackColor = false;
            this.mathiBolau.Click += new System.EventHandler(this.mathiBolau_Click);
            // 
            // show
            // 
            this.show.Location = new System.Drawing.Point(518, 215);
            this.show.Name = "show";
            this.show.Size = new System.Drawing.Size(152, 46);
            this.show.TabIndex = 2;
            this.show.UseVisualStyleBackColor = true;
            this.show.Click += new System.EventHandler(this.show_Click);
            // 
            // mathiTimer
            // 
            this.mathiTimer.Tick += new System.EventHandler(this.mathiTimer_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox2.Location = new System.Drawing.Point(489, 197);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(203, 241);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // ldoor1
            // 
            this.ldoor1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ldoor1.Location = new System.Drawing.Point(115, 50);
            this.ldoor1.Name = "ldoor1";
            this.ldoor1.Size = new System.Drawing.Size(86, 211);
            this.ldoor1.TabIndex = 4;
            this.ldoor1.TabStop = false;
            // 
            // rdoor1
            // 
            this.rdoor1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.rdoor1.Location = new System.Drawing.Point(199, 50);
            this.rdoor1.Name = "rdoor1";
            this.rdoor1.Size = new System.Drawing.Size(94, 211);
            this.rdoor1.TabIndex = 5;
            this.rdoor1.TabStop = false;
            // 
            // rdoorg
            // 
            this.rdoorg.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.rdoorg.Location = new System.Drawing.Point(199, 349);
            this.rdoorg.Name = "rdoorg";
            this.rdoorg.Size = new System.Drawing.Size(94, 211);
            this.rdoorg.TabIndex = 6;
            this.rdoorg.TabStop = false;
            // 
            // ldoorg
            // 
            this.ldoorg.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ldoorg.Location = new System.Drawing.Point(115, 349);
            this.ldoorg.Name = "ldoorg";
            this.ldoorg.Size = new System.Drawing.Size(86, 211);
            this.ldoorg.TabIndex = 7;
            this.ldoorg.TabStop = false;
            // 
            // TalaBolau
            // 
            this.TalaBolau.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TalaBolau.Location = new System.Drawing.Point(321, 419);
            this.TalaBolau.Name = "TalaBolau";
            this.TalaBolau.Size = new System.Drawing.Size(55, 58);
            this.TalaBolau.TabIndex = 8;
            this.TalaBolau.UseVisualStyleBackColor = false;
            this.TalaBolau.Click += new System.EventHandler(this.TalaBolau_Click);
            // 
            // mathi
            // 
            this.mathi.Location = new System.Drawing.Point(518, 288);
            this.mathi.Name = "mathi";
            this.mathi.Size = new System.Drawing.Size(55, 58);
            this.mathi.TabIndex = 9;
            this.mathi.UseVisualStyleBackColor = true;
            this.mathi.Click += new System.EventHandler(this.mathi_Click);
            // 
            // tala
            // 
            this.tala.Location = new System.Drawing.Point(604, 288);
            this.tala.Name = "tala";
            this.tala.Size = new System.Drawing.Size(55, 58);
            this.tala.TabIndex = 10;
            this.tala.UseVisualStyleBackColor = true;
            this.tala.Click += new System.EventHandler(this.tala_Click);
            // 
            // dhokaOpen
            // 
            this.dhokaOpen.Location = new System.Drawing.Point(518, 367);
            this.dhokaOpen.Name = "dhokaOpen";
            this.dhokaOpen.Size = new System.Drawing.Size(55, 58);
            this.dhokaOpen.TabIndex = 11;
            this.dhokaOpen.UseVisualStyleBackColor = true;
            this.dhokaOpen.Click += new System.EventHandler(this.dhokaOpen_Click);
            // 
            // dhokaClose
            // 
            this.dhokaClose.Location = new System.Drawing.Point(604, 367);
            this.dhokaClose.Name = "dhokaClose";
            this.dhokaClose.Size = new System.Drawing.Size(55, 58);
            this.dhokaClose.TabIndex = 12;
            this.dhokaClose.UseVisualStyleBackColor = true;
            this.dhokaClose.Click += new System.EventHandler(this.dhokaClose_Click);
            // 
            // talaTimer
            // 
            this.talaTimer.Tick += new System.EventHandler(this.talaTimer_Tick);
            // 
            // dhokaKhulla
            // 
            this.dhokaKhulla.Tick += new System.EventHandler(this.dhokaKhulla_Tick);
            // 
            // dhokaBanda
            // 
            this.dhokaBanda.Tick += new System.EventHandler(this.dhokaBanda_Tick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(732, 110);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(298, 421);
            this.dataGridView1.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 589);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dhokaClose);
            this.Controls.Add(this.dhokaOpen);
            this.Controls.Add(this.tala);
            this.Controls.Add(this.mathi);
            this.Controls.Add(this.TalaBolau);
            this.Controls.Add(this.ldoorg);
            this.Controls.Add(this.rdoorg);
            this.Controls.Add(this.rdoor1);
            this.Controls.Add(this.ldoor1);
            this.Controls.Add(this.show);
            this.Controls.Add(this.mathiBolau);
            this.Controls.Add(this.mainBase);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.mainBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ldoor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoor1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoorg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ldoorg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox mainBase;
        private System.Windows.Forms.Button mathiBolau;
        private System.Windows.Forms.Button show;
        private System.Windows.Forms.Timer mathiTimer;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox ldoor1;
        private System.Windows.Forms.PictureBox rdoor1;
        private System.Windows.Forms.PictureBox rdoorg;
        private System.Windows.Forms.PictureBox ldoorg;
        private System.Windows.Forms.Button TalaBolau;
        private System.Windows.Forms.Button mathi;
        private System.Windows.Forms.Button tala;
        private System.Windows.Forms.Button dhokaOpen;
        private System.Windows.Forms.Button dhokaClose;
        private System.Windows.Forms.Timer talaTimer;
        private System.Windows.Forms.Timer dhokaKhulla;
        private System.Windows.Forms.Timer dhokaBanda;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

