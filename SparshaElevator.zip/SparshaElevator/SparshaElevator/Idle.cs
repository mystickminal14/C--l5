﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SparshaElevator
{
    internal class Idle : IElevator
    {
        public void ElevatorCloseDoor(Elevator elevator)
        {
        }

        public void ElevatorMoveDown(Elevator elevator)
        {
        }

        

        public void ElevatorMoveUp(Elevator elevator)
        {
        }

        public void ElevatorOpenDoor(Elevator elevator)
        {
        }
    }
}
